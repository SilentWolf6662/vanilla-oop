# vanilla-oop
 This is a simple project that I made to practice OOP in TypeScript. It's a simple website that displays a list of all my projects and their details.
